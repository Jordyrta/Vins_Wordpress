<?php

interface DUPX_interface_test
{
    public static function preTestPrepare();

    public static function afterTestClean();
}
